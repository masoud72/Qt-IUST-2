#ifndef MOALEM_H
#define MOALEM_H

#include <QWidget>

namespace Ui {
class Moalem;
}

class Moalem : public QWidget
{
    Q_OBJECT
    
public:
    explicit Moalem(QWidget *parent = 0);
    ~Moalem();
    
private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::Moalem *ui;
};

#endif // MOALEM_H
