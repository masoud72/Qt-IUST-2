#include "nazem3.h"
#include "ui_nazem3.h"
#include<QSqlQuery>
#include<QString>
#include<QSqlError>
#include<QDebug>
#include<QTableWidgetItem>
Nazem3::Nazem3(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Nazem3)
{
    ui->setupUi(this);
    set_table();
}

Nazem3::~Nazem3()
{
    delete ui;
}


void Nazem3::on_pushButton_3_clicked()
{
    Nazem1 *na1;
    na1 = new Nazem1;
    na1->show();
    this->close();

}

void Nazem3::set_table()
{
    QSqlQuery q;
    int row=0;
    q.exec("SELECT * FROM student_t");
    while (q.next()) {

        QString name=q.value( 0 ).toString();
        QString math_str=q.value(5).toString();
        QString physic_str=q.value( 6 ).toString();
        QString chemistry_str=q.value( 7 ).toString();

        int math_int=q.value(5).toInt();
        int physic_int=q.value( 6 ).toInt();
        int chemistry_int=q.value( 7 ).toInt();
        float average=(float)(math_int+physic_int+chemistry_int)/3;
        ui->tableWidget->insertRow(row);

        ui->tableWidget->setItem(row,0,new QTableWidgetItem(name));
        ui->tableWidget->setItem(row,1,new QTableWidgetItem(math_str));
        ui->tableWidget->setItem(row,2,new QTableWidgetItem(physic_str));
        ui->tableWidget->setItem(row,3,new QTableWidgetItem(chemistry_str));
        ui->tableWidget->setItem(row,4,new QTableWidgetItem(QString::number(average)));
        row++;
         qDebug()<<q.lastError()<<row<<name;
    }




}
