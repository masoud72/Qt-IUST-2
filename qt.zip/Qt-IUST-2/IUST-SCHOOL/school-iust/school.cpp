#include "school.h"
#include "ui_school.h"
#include <QString>
#include <QDebug>
#include<QSqlDatabase>
#include<QSqlQuery>
#include<QSqlError>
#include<QLabel>
int m = 0 ;
int h = 0 ;
int u = 0 ;
int g = 0 ;
int assis = 0 ;
int teach = 0 ;
bool is_teacher=false;
bool is_assistant=false;
QString newusr;
QString newpass;
School::School(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::School)
{
    ui->setupUi(this);
    set_db("nazem1" , "nazem1");
    set_db("moalem1" , "moalem1");
}

School::~School()
{
    delete ui;
}


void School :: set_db( QString usern , QString pass ) {

    QSqlDatabase db1 =QSqlDatabase::addDatabase("QSQLITE");
    db1.setDatabaseName("school1.db");
    bool isOpen = db1.open() ;
    QSqlQuery q(db1);

    if ( g == 0 ) {
    //Create login_t as login table
    q.exec("CREATE TABLE login_t (user VARCHAR(30),pass VARCHAR(30)) ");
                   }
    g = g + 1 ;
    q.exec( "INSERT INTO login_t (user, pass) VALUES ('"+usern+"','"+pass+"')") ;
    /*QString queryString = "INSERT INTO login_t (user, pass) VALUES (?,?)";
    q(queryString);
    q.addBindValue(usern);
    q.addBindValue(pass);
    q.exec();*/
    //set nazem user and password
    //q.exec("INSERT INTO login_t(usern,pass,1) VALUES (user,pass,id)");

    //set moalem1 user and password
    //q.exec("INSERT INTO login_t(user,pass,id)VALUES ('moalem1','moalem1',2)");

    qDebug() <<isOpen << q.lastError(); //showing the database condition


}


void School::on_pushButton_2_clicked()
{
    exit(1);
}

void School::on_lineEdit_textEdited(const QString &arg1)
{
    user = arg1;
    newusr = user;

    QString user_name ;


    QSqlQuery query1;
    query1.prepare( "SELECT * FROM login_t " );


    if( !query1.exec() )
    {
      qDebug () << " ERROR"; // Error Handling, check query.lastError(), probably return
    }

    // Note: if you don't return in case of an error, put this into the else{} part
    while( query1.next() )
    {
        user_name = query1.value( 0 ).toString();
        qDebug() << "user" << user_name ;
        if ( user == user_name) {
            h = h + 1 ;
            if(user=="moalem1")
                is_teacher=true;
            else if(user=="nazem1")
                is_assistant=true;
            break ;
        }
    }

    /*QSqlDatabase db1 =QSqlDatabase::addDatabase("QSQLITE");
    db1.setDatabaseName( "school1.db");
    bool isOpen = db1.open() ;
    QSqlQuery q(db1);*/




}



void School::on_lineEdit_2_textEdited(const QString &arg1)
{
    pass = arg1;
    newpass = pass;

    QString password ;
    QSqlQuery query2;
    query2.prepare( "SELECT * FROM login_t " );

    if( !query2.exec() )
    {
      qDebug () << " ERROR" ;// Error Handling, check query.lastError(), probably return
    }

    // Note: if you don't return in case of an error, put this into the else{} part
    while( query2.next() )
    {
        password = query2.value( 1 ).toString();
        qDebug() << "pass" << password ;
        if ( pass == password ) {
            m = m + 1 ;

            break ;
        }
    }
}

void School::on_pushButton_clicked()
{


    if ( m == 1 && h == 1 )
    {
        if ( assis == 0 && teach == 0 )
        {
            on_label_10_linkActivated("err");
        }
        else {
            //qDebug()<<"ass="<<is_assistant<<"tea"<<is_teacher;
        if(assis == 1 )
            na1.show();
        else if(teach == 1)
            moa.show();
        this->close();
         }
    }
   else {
        on_label_4_linkActivated("ERROR");
    }

}

void School::on_label_4_linkActivated(const QString &link)
{
    if ( m != 1 && h != 1 ){
                ui->label_4->setText(  " Your Username and Password are invalid" ) ;
            }

            else  {
                if ( m != 1 ) {
                ui->label_4->setText(  " Your Password is invalid " ) ;
                }
                if ( h != 1 ) {
                   ui->label_4->setText(  "Your Username is invalid" );
                }

            }
}


void School::on_lineEdit_3_textEdited(const QString &arg1)
{
  security  = arg1 ;
  if ( security == "245896") u = u + 1 ;

}

void School::on_label_8_linkActivated(const QString &link)
{
    if ( u != 1 ) {
        ui->label_8->setText("Your Security Code is Invalid");
    }
    if ( u == 1 ) { ui->label_8->setText(" Your New User Succeesfully Saved");
                  }
}

void School::on_pushButton_3_clicked()
{
    on_label_8_linkActivated("er");
    if ( u == 1 ) {

        set_db ( newusr , newpass ) ;
    }
}



void School::on_checkBox_2_clicked()
{   qDebug()<<"check box assistant";
    if ( ui->checkBox_2->isChecked() == true ) assis = assis + 1 ;

}

void School::on_checkBox_clicked()
{
    if ( ui->checkBox->isChecked() == true ) teach = teach + 1 ;
}

void School::on_label_10_linkActivated(const QString &link)
{
    ui->label_10->setText(" No User Type Seelected");
}
