/********************************************************************************
** Form generated from reading UI file 'school.ui'
**
** Created: Sat Jun 1 10:18:23 2013
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SCHOOL_H
#define UI_SCHOOL_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_School
{
public:
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QWidget *horizontalLayoutWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *label_2;
    QLineEdit *lineEdit;
    QWidget *horizontalLayoutWidget_2;
    QHBoxLayout *horizontalLayout_2;
    QLabel *label_3;
    QLineEdit *lineEdit_2;
    QWidget *horizontalLayoutWidget_3;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *pushButton_2;
    QPushButton *pushButton;
    QPushButton *pushButton_3;
    QLabel *label_4;
    QWidget *horizontalLayoutWidget_4;
    QHBoxLayout *horizontalLayout_4;
    QLabel *label_5;
    QLabel *label_6;
    QLineEdit *lineEdit_3;
    QLabel *label_9;
    QLabel *label_7;
    QLabel *label_8;
    QCheckBox *checkBox;
    QCheckBox *checkBox_2;
    QLabel *label_10;

    void setupUi(QWidget *School)
    {
        if (School->objectName().isEmpty())
            School->setObjectName(QString::fromUtf8("School"));
        School->resize(551, 417);
        verticalLayoutWidget = new QWidget(School);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(0, 0, 241, 41));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label = new QLabel(verticalLayoutWidget);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout->addWidget(label);

        horizontalLayoutWidget = new QWidget(School);
        horizontalLayoutWidget->setObjectName(QString::fromUtf8("horizontalLayoutWidget"));
        horizontalLayoutWidget->setGeometry(QRect(30, 50, 231, 41));
        horizontalLayout = new QHBoxLayout(horizontalLayoutWidget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(horizontalLayoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        horizontalLayout->addWidget(label_2);

        lineEdit = new QLineEdit(horizontalLayoutWidget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));

        horizontalLayout->addWidget(lineEdit);

        horizontalLayoutWidget_2 = new QWidget(School);
        horizontalLayoutWidget_2->setObjectName(QString::fromUtf8("horizontalLayoutWidget_2"));
        horizontalLayoutWidget_2->setGeometry(QRect(30, 100, 231, 41));
        horizontalLayout_2 = new QHBoxLayout(horizontalLayoutWidget_2);
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(horizontalLayoutWidget_2);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_2->addWidget(label_3);

        lineEdit_2 = new QLineEdit(horizontalLayoutWidget_2);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setEchoMode(QLineEdit::Password);

        horizontalLayout_2->addWidget(lineEdit_2);

        horizontalLayoutWidget_3 = new QWidget(School);
        horizontalLayoutWidget_3->setObjectName(QString::fromUtf8("horizontalLayoutWidget_3"));
        horizontalLayoutWidget_3->setGeometry(QRect(40, 360, 309, 51));
        horizontalLayout_3 = new QHBoxLayout(horizontalLayoutWidget_3);
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        pushButton_2 = new QPushButton(horizontalLayoutWidget_3);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));

        horizontalLayout_3->addWidget(pushButton_2);

        pushButton = new QPushButton(horizontalLayoutWidget_3);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        horizontalLayout_3->addWidget(pushButton);

        pushButton_3 = new QPushButton(horizontalLayoutWidget_3);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));

        horizontalLayout_3->addWidget(pushButton_3);

        label_4 = new QLabel(School);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(30, 150, 341, 20));
        horizontalLayoutWidget_4 = new QWidget(School);
        horizontalLayoutWidget_4->setObjectName(QString::fromUtf8("horizontalLayoutWidget_4"));
        horizontalLayoutWidget_4->setGeometry(QRect(20, 180, 421, 41));
        horizontalLayout_4 = new QHBoxLayout(horizontalLayoutWidget_4);
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setContentsMargins(11, 11, 11, 11);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        label_5 = new QLabel(horizontalLayoutWidget_4);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        horizontalLayout_4->addWidget(label_5);

        label_6 = new QLabel(horizontalLayoutWidget_4);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        horizontalLayout_4->addWidget(label_6);

        lineEdit_3 = new QLineEdit(horizontalLayoutWidget_4);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setEchoMode(QLineEdit::Password);

        horizontalLayout_4->addWidget(lineEdit_3);

        label_9 = new QLabel(horizontalLayoutWidget_4);
        label_9->setObjectName(QString::fromUtf8("label_9"));

        horizontalLayout_4->addWidget(label_9);

        label_7 = new QLabel(School);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(310, 10, 161, 141));
        label_8 = new QLabel(School);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(40, 240, 281, 31));
        checkBox = new QCheckBox(School);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setGeometry(QRect(400, 310, 98, 22));
        checkBox_2 = new QCheckBox(School);
        checkBox_2->setObjectName(QString::fromUtf8("checkBox_2"));
        checkBox_2->setGeometry(QRect(280, 310, 98, 22));
        label_10 = new QLabel(School);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(36, 310, 221, 20));

        retranslateUi(School);

        QMetaObject::connectSlotsByName(School);
    } // setupUi

    void retranslateUi(QWidget *School)
    {
        School->setWindowTitle(QApplication::translate("School", "School", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("School", "\331\206\330\247\331\205 \332\251\330\247\330\261\330\250\330\261\333\214 \331\210 \330\261\331\205\330\262 \330\261\330\247 \331\210\330\247\330\261\330\257 \332\251\331\206\333\214\330\257 :", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("School", "\331\206\330\247\331\205 \332\251\330\247\330\261\330\250\330\261\333\214", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("School", "\330\261\331\205\330\262 \331\210\330\261\331\210\330\257", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("School", "\330\256\330\261\331\210\330\254", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("School", "\331\210\330\261\331\210\330\257", 0, QApplication::UnicodeUTF8));
        pushButton_3->setText(QApplication::translate("School", "\330\263\330\247\330\256\330\252 \332\251\330\247\330\261\330\250\330\261 \330\254\330\257\333\214\330\257", 0, QApplication::UnicodeUTF8));
        label_4->setText(QString());
        label_5->setText(QApplication::translate("School", "\332\251\330\257 \330\247\331\205\331\206\333\214\330\252 ", 0, QApplication::UnicodeUTF8));
        label_6->setText(QString());
        label_9->setText(QApplication::translate("School", "\330\250\330\261\330\247\333\214 \330\253\330\250\330\252 \331\206\330\247\331\205 \332\251\330\247\330\261\330\250\330\261 \330\254\330\257\333\214\330\257", 0, QApplication::UnicodeUTF8));
        label_7->setText(QApplication::translate("School", "For making a new\n"
"User Please enter\n"
"new Username and\n"
"Password and Security \n"
"code then press Creat\n"
"New User\n"
"Dont Use Check Boxes\n"
"In This Step", 0, QApplication::UnicodeUTF8));
        label_8->setText(QString());
        checkBox->setText(QApplication::translate("School", "\331\205\330\271\331\204\331\205", 0, QApplication::UnicodeUTF8));
        checkBox_2->setText(QApplication::translate("School", "\331\206\330\247\330\270\331\205", 0, QApplication::UnicodeUTF8));
        label_10->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class School: public Ui_School {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SCHOOL_H
