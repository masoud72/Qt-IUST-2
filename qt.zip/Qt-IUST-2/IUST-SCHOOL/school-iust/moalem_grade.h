#ifndef MOALEM_GRADE_H
#define MOALEM_GRADE_H

#include <QWidget>

namespace Ui {
class moalem_grade;
}

class moalem_grade : public QWidget
{
    Q_OBJECT
    
public:
    explicit moalem_grade(QWidget *parent = 0);
    ~moalem_grade();
    void set_table()  ;
private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::moalem_grade *ui;
};

#endif // MOALEM_GRADE_H
