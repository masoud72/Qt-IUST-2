/********************************************************************************
** Form generated from reading UI file 'moalem_grade.ui'
**
** Created: Sat Jun 1 09:41:26 2013
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MOALEM_GRADE_H
#define UI_MOALEM_GRADE_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>
#include <QtGui/QTableWidget>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_moalem_grade
{
public:
    QTableWidget *tableWidget;
    QPushButton *pushButton;
    QPushButton *pushButton_2;

    void setupUi(QWidget *moalem_grade)
    {
        if (moalem_grade->objectName().isEmpty())
            moalem_grade->setObjectName(QString::fromUtf8("moalem_grade"));
        moalem_grade->resize(498, 300);
        tableWidget = new QTableWidget(moalem_grade);
        if (tableWidget->columnCount() < 4)
            tableWidget->setColumnCount(4);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        QTableWidgetItem *__qtablewidgetitem2 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(2, __qtablewidgetitem2);
        QTableWidgetItem *__qtablewidgetitem3 = new QTableWidgetItem();
        tableWidget->setHorizontalHeaderItem(3, __qtablewidgetitem3);
        tableWidget->setObjectName(QString::fromUtf8("tableWidget"));
        tableWidget->setGeometry(QRect(50, 20, 401, 192));
        pushButton = new QPushButton(moalem_grade);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(130, 250, 99, 27));
        pushButton_2 = new QPushButton(moalem_grade);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(250, 250, 99, 27));

        retranslateUi(moalem_grade);

        QMetaObject::connectSlotsByName(moalem_grade);
    } // setupUi

    void retranslateUi(QWidget *moalem_grade)
    {
        moalem_grade->setWindowTitle(QApplication::translate("moalem_grade", "Form", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem = tableWidget->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QApplication::translate("moalem_grade", "\331\206\330\247\331\205", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QApplication::translate("moalem_grade", "\331\201\333\214\330\262\333\214\332\251", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem2 = tableWidget->horizontalHeaderItem(2);
        ___qtablewidgetitem2->setText(QApplication::translate("moalem_grade", "\330\261\333\214\330\247\330\266\333\214", 0, QApplication::UnicodeUTF8));
        QTableWidgetItem *___qtablewidgetitem3 = tableWidget->horizontalHeaderItem(3);
        ___qtablewidgetitem3->setText(QApplication::translate("moalem_grade", "\330\264\333\214\331\205\333\214", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("moalem_grade", "\330\250\330\247\330\262\332\257\330\264\330\252", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("moalem_grade", "\330\260\330\256\333\214\330\261\331\207", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class moalem_grade: public Ui_moalem_grade {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MOALEM_GRADE_H
