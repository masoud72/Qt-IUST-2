#ifndef SCHOOL_H
#define SCHOOL_H

#include <QWidget>
#include <QString>
#include "nazem1.h"
#include <QtSql/QSqlDatabase>
#include <QtSql/QSqlQuery>
#include"moalem.h"

namespace Ui {
class School;
}

class School : public QWidget
{
    Q_OBJECT
    
public:
    explicit School(QWidget *parent = 0);
    ~School();
    Nazem1 na1;
    Moalem moa;
    void set_db (QString usern , QString pass) ;

    
private slots:
    void on_pushButton_2_clicked();

    void on_lineEdit_textEdited(const QString &arg1);

    void on_lineEdit_2_textEdited(const QString &arg1);

    void on_pushButton_clicked();



    void on_label_4_linkActivated(const QString &link);



    void on_lineEdit_3_textEdited(const QString &arg1);

    void on_label_8_linkActivated(const QString &link);

    void on_pushButton_3_clicked();





    void on_checkBox_2_clicked();

    void on_checkBox_clicked();

    void on_label_10_linkActivated(const QString &link);

private:
    Ui::School *ui;
    QString user;
    QString pass;
    QString security;




};

#endif // SCHOOL_H
