#include "moalem_grade.h"
#include<QSqlQuery>
#include "ui_moalem_grade.h"
#include "moalem.h"
#include<QSqlError>
#include<QDebug>
#include<QTableWidgetItem>
#include<QSqlDatabase>
int row1=0;
moalem_grade::moalem_grade(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::moalem_grade)
{
    ui->setupUi(this);
    set_table();
}

moalem_grade::~moalem_grade()
{
    delete ui;
}
//back
void moalem_grade::on_pushButton_clicked()
{
    Moalem *m=new Moalem ;
    m->show();
    this->close();


}

void moalem_grade::set_table()
{
    QSqlQuery q;

    q.exec("SELECT * FROM student_t");
    while (q.next()) {

        QString name=q.value( 0 ).toString();
        QString math_str=q.value(5).toString();
        QString physic_str=q.value( 6 ).toString();
        QString chemistry_str=q.value( 7 ).toString();


        ui->tableWidget->insertRow(row1);

        ui->tableWidget->setItem(row1,0,new QTableWidgetItem(name));
        ui->tableWidget->setItem(row1,1,new QTableWidgetItem(math_str));
        ui->tableWidget->setItem(row1,2,new QTableWidgetItem(physic_str));
        ui->tableWidget->setItem(row1,3,new QTableWidgetItem(chemistry_str));

        row1++;
         qDebug()<<q.lastError()<<row1<<name;
}
}

void moalem_grade::on_pushButton_2_clicked()
{
    QSqlQuery q;


    for(int i=0;i<row1;i++){

        QTableWidgetItem* thename = ui->tableWidget->item(i, 0);
        QTableWidgetItem* themath = ui->tableWidget->item(i, 2);
        QTableWidgetItem* thephysic = ui->tableWidget->item(i, 1);
        QTableWidgetItem* thechemistry = ui->tableWidget->item(i, 3);
        qDebug()<<thename->text()<<themath->text();
        q.exec("UPDATE student_t SET math='"+themath->text()+"',physic='"+thephysic->text()+"',chemistry='"+thechemistry->text()+"'WHERE name='"+thename->text()+"'");
        qDebug()<<q.lastError();
        }
    Moalem *m=new Moalem ;
    m->show();
    this->close();


}
