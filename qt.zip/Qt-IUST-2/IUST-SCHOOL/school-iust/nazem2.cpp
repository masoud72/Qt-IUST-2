#include "nazem2.h"
#include "ui_nazem2.h"
#include "nazem1.h"
#include<QSqlDatabase>
#include<QSqlQuery>
#include<QDebug>
#include<QSqlError>

int row=0;
Nazem2::Nazem2(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Nazem2)
{
    ui->setupUi(this);
    set_database();
}

Nazem2::~Nazem2()
{
    delete ui;
}

void Nazem2::on_pushButton_6_clicked()
{
    Nazem1 *na1;
    na1 = new Nazem1;
    na1->show();
    this->close();

}

void Nazem2::on_pushButton_clicked()
{
    ui->tableWidget->insertRow(1);
    row+=1;


}

void Nazem2::on_pushButton_3_clicked()
{
    ui->tableWidget->removeRow(1);
    row-=1;
}
void Nazem2::set_database()
{
    QSqlDatabase db1 =QSqlDatabase::addDatabase("QSQLITE");
    db1.setDatabaseName("school1.db");
    bool isOpen = db1.open() ;
    QSqlQuery q;
    if(isOpen)

        q.exec("CREATE TABLE student_t(name VARCHAR(30),class VARCHAR(30),regularity_grade VARCHAR(30),regularity_thing VARCHAR(30),teacher VARCHAR(30),math VARCHAR(30),physic VARCHAR(30),chemistry VARCHAR(30))");


    qDebug()<<q.lastError();//<<i   sOpen;
}


void Nazem2::on_pushButton_5_clicked()
{   QSqlQuery q;
    //int row = 0;
    int col = 0;
    for(int i=0;i<=row;i++)

    {   qDebug()<<row;
        QTableWidgetItem* thename = ui->tableWidget->item(i, 0);
        QTableWidgetItem* theclass = ui->tableWidget->item(i, 1);
        QTableWidgetItem* theenzebat = ui->tableWidget->item(i, 2);
        QTableWidgetItem* themored = ui->tableWidget->item(i, 3);
        QTableWidgetItem* theteacher = ui->tableWidget->item(i, 4);

        q.exec("INSERT INTO student_t(name,class,regularity_grade,regularity_thing,teacher)VALUES('"+thename->text()+"','"+theclass->text()+"','"+theenzebat->text()+"','"+themored->text()+"','"+theteacher->text()+"')");
        qDebug()<<q.lastError();
    }
    Nazem1 *na1;
    na1 = new Nazem1;
    na1->show();
    this->close();

}
