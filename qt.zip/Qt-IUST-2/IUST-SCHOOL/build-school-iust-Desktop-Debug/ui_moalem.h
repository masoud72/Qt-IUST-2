/********************************************************************************
** Form generated from reading UI file 'moalem.ui'
**
** Created: Sat Jun 1 09:58:10 2013
**      by: Qt User Interface Compiler version 4.8.4
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MOALEM_H
#define UI_MOALEM_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QPushButton>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Moalem
{
public:
    QPushButton *pushButton;
    QLabel *label;
    QPushButton *pushButton_2;

    void setupUi(QWidget *Moalem)
    {
        if (Moalem->objectName().isEmpty())
            Moalem->setObjectName(QString::fromUtf8("Moalem"));
        Moalem->resize(400, 300);
        pushButton = new QPushButton(Moalem);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(98, 150, 151, 27));
        label = new QLabel(Moalem);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(210, 60, 121, 17));
        pushButton_2 = new QPushButton(Moalem);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(98, 210, 151, 27));

        retranslateUi(Moalem);

        QMetaObject::connectSlotsByName(Moalem);
    } // setupUi

    void retranslateUi(QWidget *Moalem)
    {
        Moalem->setWindowTitle(QApplication::translate("Moalem", "Form", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("Moalem", "\330\253\330\250\330\252 \331\206\331\205\330\261\331\207", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("Moalem", "\330\256\331\210\330\264 \330\242\331\205\330\257\333\214\330\257", 0, QApplication::UnicodeUTF8));
        pushButton_2->setText(QApplication::translate("Moalem", "\330\250\330\247\330\262\332\257\330\264\330\252", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class Moalem: public Ui_Moalem {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MOALEM_H
