#include "moalem.h"
#include "ui_moalem.h"
#include "moalem_grade.h"
#include "school.h"
Moalem::Moalem(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Moalem)
{
    ui->setupUi(this);
}

Moalem::~Moalem()
{
    delete ui;
}

void Moalem::on_pushButton_clicked()
{
    moalem_grade* na=new moalem_grade;
    na->show();
    this->close();

}

void Moalem::on_pushButton_2_clicked()
{
    School* s=new School;
    s->show();
    this->close();
}
