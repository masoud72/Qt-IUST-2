/****************************************************************************
** Meta object code from reading C++ file 'school.h'
**
** Created: Sat Jun 1 10:06:27 2013
**      by: The Qt Meta Object Compiler version 63 (Qt 4.8.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../school-iust/school.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'school.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 63
#error "This file was generated using the moc from 4.8.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_School[] = {

 // content:
       6,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
       8,    7,    7,    7, 0x08,
      39,   34,    7,    7, 0x08,
      71,   34,    7,    7, 0x08,
     105,    7,    7,    7, 0x08,
     134,  129,    7,    7, 0x08,
     168,   34,    7,    7, 0x08,
     202,  129,    7,    7, 0x08,
     236,    7,    7,    7, 0x08,
     262,    7,    7,    7, 0x08,
     286,    7,    7,    7, 0x08,
     308,  129,    7,    7, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_School[] = {
    "School\0\0on_pushButton_2_clicked()\0"
    "arg1\0on_lineEdit_textEdited(QString)\0"
    "on_lineEdit_2_textEdited(QString)\0"
    "on_pushButton_clicked()\0link\0"
    "on_label_4_linkActivated(QString)\0"
    "on_lineEdit_3_textEdited(QString)\0"
    "on_label_8_linkActivated(QString)\0"
    "on_pushButton_3_clicked()\0"
    "on_checkBox_2_clicked()\0on_checkBox_clicked()\0"
    "on_label_10_linkActivated(QString)\0"
};

void School::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Q_ASSERT(staticMetaObject.cast(_o));
        School *_t = static_cast<School *>(_o);
        switch (_id) {
        case 0: _t->on_pushButton_2_clicked(); break;
        case 1: _t->on_lineEdit_textEdited((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 2: _t->on_lineEdit_2_textEdited((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 3: _t->on_pushButton_clicked(); break;
        case 4: _t->on_label_4_linkActivated((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 5: _t->on_lineEdit_3_textEdited((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 6: _t->on_label_8_linkActivated((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 7: _t->on_pushButton_3_clicked(); break;
        case 8: _t->on_checkBox_2_clicked(); break;
        case 9: _t->on_checkBox_clicked(); break;
        case 10: _t->on_label_10_linkActivated((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObjectExtraData School::staticMetaObjectExtraData = {
    0,  qt_static_metacall 
};

const QMetaObject School::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_School,
      qt_meta_data_School, &staticMetaObjectExtraData }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &School::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *School::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *School::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_School))
        return static_cast<void*>(const_cast< School*>(this));
    return QWidget::qt_metacast(_clname);
}

int School::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
